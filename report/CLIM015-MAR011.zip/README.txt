README

The contents of this zip file contains several csv files and images.
There are results for both ICES divisions and MSFD european sea
regions, indicated by a suffix on the file name.

